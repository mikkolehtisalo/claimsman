/*++

Module Name:

claimsman.c

Abstract:

This is the main module of the claimsman miniFilter driver.

Environment:

Kernel mode

--*/

#include <fltKernel.h>
#include <dontuse.h>
#include <suppress.h>
#include "claimsman.h"

#pragma prefast(disable:__WARNING_ENCODE_MEMBER_FUNCTION_POINTER, "Not valid for kernel mode drivers")
#pragma inline_depth(0)

ULONG_PTR OperationStatusCtx = 1;

#define PTDBG_TRACE_ROUTINES            0x00000001
#define PTDBG_TRACE_OPERATION_STATUS    0x00000002

ULONG gTraceFlags = 1;

#define PT_DBG_PRINT( _dbgLevel, _string )          \
    (FlagOn(gTraceFlags,(_dbgLevel)) ?              \
        DbgPrint _string :                          \
        ((int)0))

/*************************************************************************
	Prototypes
	*************************************************************************/

DRIVER_INITIALIZE DriverEntry;
NTSTATUS
DriverEntry(
_In_ PDRIVER_OBJECT DriverObject,
_In_ PUNICODE_STRING RegistryPath
);

NTSTATUS
claimsmanInstanceSetup(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_SETUP_FLAGS Flags,
_In_ DEVICE_TYPE VolumeDeviceType,
_In_ FLT_FILESYSTEM_TYPE VolumeFilesystemType
);

VOID
claimsmanInstanceTeardownStart(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_TEARDOWN_FLAGS Flags
);

VOID
claimsmanInstanceTeardownComplete(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_TEARDOWN_FLAGS Flags
);

NTSTATUS
claimsmanUnload(
_In_ FLT_FILTER_UNLOAD_FLAGS Flags
);

NTSTATUS
claimsmanInstanceQueryTeardown(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags
);

FLT_PREOP_CALLBACK_STATUS
claimsmanPreOperation(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_Flt_CompletionContext_Outptr_ PVOID *CompletionContext
);

VOID
claimsmanOperationStatusCallback(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ PFLT_IO_PARAMETER_BLOCK ParameterSnapshot,
_In_ NTSTATUS OperationStatus,
_In_ PVOID RequesterContext
);

FLT_POSTOP_CALLBACK_STATUS
claimsmanPostOperation(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_opt_ PVOID CompletionContext,
_In_ FLT_POST_OPERATION_FLAGS Flags
);

FLT_PREOP_CALLBACK_STATUS
claimsmanPreOperationNoPostOperation(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_Flt_CompletionContext_Outptr_ PVOID *CompletionContext
);

BOOLEAN
claimsmanDoRequestOperationStatus(
_In_ PFLT_CALLBACK_DATA Data
);

NTSTATUS
ClaimsmanMessage(
_In_ PVOID ConnectionCookie,
_In_reads_bytes_opt_(InputBufferSize) PVOID InputBuffer,
_In_ ULONG InputBufferSize,
_Out_writes_bytes_to_opt_(OutputBufferSize, *ReturnOutputBufferLength) PVOID OutputBuffer,
_In_ ULONG OutputBufferSize,
_Out_ PULONG ReturnOutputBufferLength
);

NTSTATUS
ClaimsmanConnect(
_In_ PFLT_PORT ClientPort,
_In_ PVOID ServerPortCookie,
_In_reads_bytes_(SizeOfContext) PVOID ConnectionContext,
_In_ ULONG SizeOfContext,
_Flt_ConnectionCookie_Outptr_ PVOID *ConnectionCookie
);

VOID
ClaimsmanDisconnect(
_In_opt_ PVOID ConnectionCookie
);

NTSTATUS
InitializeMonitoredExtensions(
_In_ PUNICODE_STRING RegistryPath
);

VOID
ClaimsmanFreeExtensions(
);

NTSTATUS
ClaimsmanAllocateUnicodeString(
_Inout_ PUNICODE_STRING String
);

VOID
ClaimsmanFreeUnicodeString(
_Inout_ PUNICODE_STRING String
);

BOOLEAN
ClaimsmanCheckExtension(
_In_ PUNICODE_STRING Extension
);

//
//  The default extension to monitor if not configured in the registry
//

UNICODE_STRING MonitoredExtensionDefault = RTL_CONSTANT_STRING(L"docx");

//
//  Assign text sections for each routine.
//

#ifdef ALLOC_PRAGMA
#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(INIT, InitializeMonitoredExtensions)    
#pragma alloc_text(PAGE, claimsmanUnload)
#pragma alloc_text(PAGE, claimsmanInstanceQueryTeardown)
#pragma alloc_text(PAGE, claimsmanInstanceSetup)
#pragma alloc_text(PAGE, claimsmanInstanceTeardownStart)
#pragma alloc_text(PAGE, claimsmanInstanceTeardownComplete)
#pragma alloc_text(PAGE, ClaimsmanFreeExtensions)    
#pragma alloc_text(PAGE, ClaimsmanAllocateUnicodeString)
#pragma alloc_text(PAGE, ClaimsmanFreeUnicodeString)
#endif

//
//  operation registration
//

CONST FLT_OPERATION_REGISTRATION Callbacks[] = {
	/*
	The I/O Manager sends the IRP_MJ_CREATE request when a new file or directory is being created, or when an existing file, device, directory, or volume is being opened.
	*/
	{ IRP_MJ_CREATE,
	0,
	NULL,
	claimsmanPostOperation },

	{ IRP_MJ_OPERATION_END }
};

//
//  This defines what we want to filter with FltMgr
//

CONST FLT_REGISTRATION FilterRegistration = {

	sizeof(FLT_REGISTRATION),         //  Size
	FLT_REGISTRATION_VERSION,           //  Version
	0,                                  //  Flags

	NULL,                               //  Context
	Callbacks,                          //  Operation callbacks

	claimsmanUnload,                           //  MiniFilterUnload

	claimsmanInstanceSetup,                    //  InstanceSetup
	claimsmanInstanceQueryTeardown,            //  InstanceQueryTeardown
	claimsmanInstanceTeardownStart,            //  InstanceTeardownStart
	claimsmanInstanceTeardownComplete,         //  InstanceTeardownComplete

	NULL,                               //  GenerateFileName
	NULL,                               //  GenerateDestinationFileName
	NULL                                //  NormalizeNameComponent

};

CLAIMSMAN_DATA ClaimsmanData;

NTSTATUS
claimsmanInstanceSetup(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_SETUP_FLAGS Flags,
_In_ DEVICE_TYPE VolumeDeviceType,
_In_ FLT_FILESYSTEM_TYPE VolumeFilesystemType
)
/*++

Routine Description:

This routine is called whenever a new instance is created on a volume. This
gives us a chance to decide if we need to attach to this volume or not.

If this routine is not defined in the registration structure, automatic
instances are always created.

Arguments:

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Flags - Flags describing the reason for this attach request.

Return Value:

STATUS_SUCCESS - attach
STATUS_FLT_DO_NOT_ATTACH - do not attach

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);
	UNREFERENCED_PARAMETER(VolumeDeviceType);
	UNREFERENCED_PARAMETER(VolumeFilesystemType);

	PAGED_CODE();

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanInstanceSetup: Entered\n"));

	return STATUS_SUCCESS;
}


NTSTATUS
claimsmanInstanceQueryTeardown(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags
)
/*++

Routine Description:

This is called when an instance is being manually deleted by a
call to FltDetachVolume or FilterDetach thereby giving us a
chance to fail that detach request.

If this routine is not defined in the registration structure, explicit
detach requests via FltDetachVolume or FilterDetach will always be
failed.

Arguments:

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Flags - Indicating where this detach request came from.

Return Value:

Returns the status of this operation.

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);

	PAGED_CODE();

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanInstanceQueryTeardown: Entered\n"));

	return STATUS_SUCCESS;
}


VOID
claimsmanInstanceTeardownStart(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_TEARDOWN_FLAGS Flags
)
/*++

Routine Description:

This routine is called at the start of instance teardown.

Arguments:

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Flags - Reason why this instance is being deleted.

Return Value:

None.

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);

	PAGED_CODE();

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanInstanceTeardownStart: Entered\n"));
}


VOID
claimsmanInstanceTeardownComplete(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ FLT_INSTANCE_TEARDOWN_FLAGS Flags
)
/*++

Routine Description:

This routine is called at the end of instance teardown.

Arguments:

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Flags - Reason why this instance is being deleted.

Return Value:

None.

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);

	PAGED_CODE();

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanInstanceTeardownComplete: Entered\n"));
}


/*************************************************************************
	MiniFilter initialization and unload routines.
	*************************************************************************/

NTSTATUS
DriverEntry(
_In_ PDRIVER_OBJECT DriverObject,
_In_ PUNICODE_STRING RegistryPath
)
/*++

Routine Description:

This is the initialization routine for this miniFilter driver.  This
registers with FltMgr and initializes all global data structures.

Arguments:

DriverObject - Pointer to driver object created by the system to
represent this driver.

RegistryPath - Unicode string identifying where the parameters for this
driver are located in the registry.

Return Value:

Routine can return non success error codes.

--*/
{
	NTSTATUS status;
	OBJECT_ATTRIBUTES oa;
	PSECURITY_DESCRIPTOR sd;
	UNICODE_STRING uniString;

	//UNREFERENCED_PARAMETER(RegistryPath);

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!DriverEntry: Entered\n"));

	//
	//  Default to NonPagedPoolNx for non paged pool allocations where supported.
	//

	ExInitializeDriverRuntime(DrvRtPoolNxOptIn);

	//
	// Obtain the extensions to monitor from the registry
	//

	status = InitializeMonitoredExtensions(RegistryPath);

	if (!NT_SUCCESS(status)) {

		status = STATUS_SUCCESS;

		ClaimsmanData.MonitoredExtensions = &MonitoredExtensionDefault;
		ClaimsmanData.MonitoredExtensionCount = 1;
	}

	//
	//  Register with FltMgr to tell it our callback routines
	//

	status = FltRegisterFilter(DriverObject,
		&FilterRegistration,
		&ClaimsmanData.Filter);

	//
	// Initialize communication port
	//

	RtlInitUnicodeString(&uniString, ClaimsmanPortName);

	//  Only ADMINs & SYSTEM can access the port

	status = FltBuildDefaultSecurityDescriptor(&sd, FLT_PORT_ALL_ACCESS);

	if (NT_SUCCESS(status)) {
		InitializeObjectAttributes(&oa,
			&uniString,
			OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
			NULL,
			sd);


		status = FltCreateCommunicationPort(ClaimsmanData.Filter,
			&ClaimsmanData.ServerPort,
			&oa,
			NULL,
			ClaimsmanConnect,
			ClaimsmanDisconnect,
			NULL,
			1);

		// Not needed anymore 
		FltFreeSecurityDescriptor(sd);

		if (!NT_SUCCESS(status)) {
			PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
				("claimsman!DriverEntry: Unable to create communication port: %d\n", status));
		}
		else {
			//
			//  Start filtering I/O.
			//

			status = FltStartFiltering(ClaimsmanData.Filter);

			if (!NT_SUCCESS(status)) {
				FltUnregisterFilter(ClaimsmanData.Filter);
				FltCloseCommunicationPort(ClaimsmanData.ServerPort);
			}
		}
	}

	return status;
}

NTSTATUS
claimsmanUnload(
_In_ FLT_FILTER_UNLOAD_FLAGS Flags
)
/*++

Routine Description:

This is the unload routine for this miniFilter driver. This is called
when the minifilter is about to be unloaded. We can fail this unload
request if this is not a mandatory unload indicated by the Flags
parameter.

Arguments:

Flags - Indicating if this is a mandatory unload.

Return Value:

Returns STATUS_SUCCESS.

--*/
{
	UNREFERENCED_PARAMETER(Flags);

	PAGED_CODE();

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanUnload: Entered\n"));

	FltCloseCommunicationPort(ClaimsmanData.ServerPort);
	FltUnregisterFilter(ClaimsmanData.Filter);
	ClaimsmanFreeExtensions();

	return STATUS_SUCCESS;
}


/*************************************************************************
	MiniFilter callback routines.
	*************************************************************************/
FLT_PREOP_CALLBACK_STATUS
claimsmanPreOperation(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_Flt_CompletionContext_Outptr_ PVOID *CompletionContext
)
/*++

Routine Description:

This routine is a pre-operation dispatch routine for this miniFilter.

This is non-pageable because it could be called on the paging path

Arguments:

Data - Pointer to the filter callbackData that is passed to us.

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance, its associated volume and
file object.

CompletionContext - The context for the completion routine for this
operation.

Return Value:

The return value is the status of the operation.

--*/
{
	NTSTATUS status;

	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(CompletionContext);

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanPreOperation: Entered\n"));

	//
	//  See if this is an operation we would like the operation status
	//  for.  If so request it.
	//
	//  NOTE: most filters do NOT need to do this.  You only need to make
	//        this call if, for example, you need to know if the oplock was
	//        actually granted.
	//

	if (claimsmanDoRequestOperationStatus(Data)) {

		status = FltRequestOperationStatusCallback(Data,
			claimsmanOperationStatusCallback,
			(PVOID)(++OperationStatusCtx));
		if (!NT_SUCCESS(status)) {

			PT_DBG_PRINT(PTDBG_TRACE_OPERATION_STATUS,
				("claimsman!claimsmanPreOperation: FltRequestOperationStatusCallback Failed, status=%08x\n",
				status));
		}
	}

	// This template code does not do anything with the callbackData, but
	// rather returns FLT_PREOP_SUCCESS_WITH_CALLBACK.
	// This passes the request down to the next miniFilter in the chain.

	return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}



VOID
claimsmanOperationStatusCallback(
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ PFLT_IO_PARAMETER_BLOCK ParameterSnapshot,
_In_ NTSTATUS OperationStatus,
_In_ PVOID RequesterContext
)
/*++

Routine Description:

This routine is called when the given operation returns from the call
to IoCallDriver.  This is useful for operations where STATUS_PENDING
means the operation was successfully queued.  This is useful for OpLocks
and directory change notification operations.

This callback is called in the context of the originating thread and will
never be called at DPC level.  The file object has been correctly
referenced so that you can access it.  It will be automatically
dereferenced upon return.

This is non-pageable because it could be called on the paging path

Arguments:

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance, its associated volume and
file object.

RequesterContext - The context for the completion routine for this
operation.

OperationStatus -

Return Value:

The return value is the status of the operation.

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanOperationStatusCallback: Entered\n"));

	PT_DBG_PRINT(PTDBG_TRACE_OPERATION_STATUS,
		("claimsman!claimsmanOperationStatusCallback: Status=%08x ctx=%p IrpMj=%02x.%02x \"%s\"\n",
		OperationStatus,
		RequesterContext,
		ParameterSnapshot->MajorFunction,
		ParameterSnapshot->MinorFunction,
		FltGetIrpName(ParameterSnapshot->MajorFunction)));
}

void
InitializeMessage(
_Inout_ CLAIMSMAN_MESSAGE *message,
_In_ PUNICODE_STRING sid,
_In_ PUNICODE_STRING name
)
/*
...
*/
{
	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanInitializeMessage: Entered\n"));

	// SID
	if (sid->Length < CLAIMSMAN_MESSAGE_SID_SIZE) {
		RtlCopyMemory(message->Sid, sid->Buffer, sizeof(WCHAR)*sid->Length);
		// NULL terminate the previous
		message->Sid[(sizeof(WCHAR)*sid->Length) + 1] = 0;
	}
	else {
		RtlCopyMemory(message->Sid, sid->Buffer, CLAIMSMAN_MESSAGE_SID_SIZE*sizeof(WCHAR));
		// NULL terminate the previous
		message->Sid[CLAIMSMAN_MESSAGE_SID_SIZE] = 0;
	}

	// FileName
	if (name->Length < CLAIMSMAN_MESSAGE_FILENAME_SIZE) {
		RtlCopyMemory(message->FileName, name->Buffer, sizeof(WCHAR)*name->Length);
		// NULL terminate the previous
		message->FileName[(sizeof(WCHAR)*name->Length) + 1] = 0;
	}
	else {
		RtlCopyMemory(message->FileName, name->Buffer, CLAIMSMAN_MESSAGE_FILENAME_SIZE*sizeof(WCHAR));
		// NULL terminate the previous
		message->FileName[CLAIMSMAN_MESSAGE_FILENAME_SIZE] = 0;
	}

}

FLT_POSTOP_CALLBACK_STATUS
claimsmanPostOperation(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_opt_ PVOID CompletionContext,
_In_ FLT_POST_OPERATION_FLAGS Flags
)
/*++

Routine Description:

This routine is the post-operation completion routine for this
miniFilter.

This is non-pageable because it may be called at DPC level.

Arguments:

Data - Pointer to the filter callbackData that is passed to us.

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance, its associated volume and
file object.

CompletionContext - The completion context set in the pre-operation routine.

Flags - Denotes whether the completion is successful or is being drained.

Return Value:

The return value is the status of the operation.

--*/
{
	UNREFERENCED_PARAMETER(Data);
	UNREFERENCED_PARAMETER(CompletionContext);
	UNREFERENCED_PARAMETER(Flags);
	NTSTATUS status;
	PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
	PUNICODE_STRING nameToUse = NULL;

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanPostOperation: Entered\n"));

	//
	//  We got a log record, if there is a file object, get its name.
	//
	//  NOTE: By default, we use the query method
	//  FLT_FILE_NAME_QUERY_ALWAYS_ALLOW_CACHE_LOOKUP
	//  because MiniSpy would like to get the name as much as possible, but
	//  can cope if we can't retrieve a name.  For a debugging type filter,
	//  like Minispy, this is reasonable, but for most production filters
	//  who need names reliably, they should query the name at times when it
	//  is known to be safe and use the query method
	//  FLT_FILE_NAME_QUERY_DEFAULT.
	//

	if (FltObjects->FileObject != NULL) {
		status = FltGetFileNameInformation(Data,
			FLT_FILE_NAME_NORMALIZED |
			FLT_FILE_NAME_QUERY_DEFAULT,
			&nameInfo);
	}
	else {
		//
		//  Can't get a name when there's no file object
		//
		status = STATUS_UNSUCCESSFUL;
	}

	//PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
	//	("claimsman!claimsmanPostOperation: status=%08x\n", status));

	if (NT_SUCCESS(status)) {
		nameToUse = &nameInfo->Name;
		//PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		//	("claimsman!claimsmanPostOperation: name=%wZ\n", nameToUse));
		FltParseFileNameInformation(nameInfo);
	}
	else
	{
		return FLT_POSTOP_FINISHED_PROCESSING;
		// No point continuing because we obviously did not get a filename anyways
	}

	// ----
	//The only IRP you can trust for user information is IRP_MJ_CREATE. Things 
	//like write can be in arbitrary thread context, and even if the call works
	//	you can get the wrong SID.

	PTOKEN_USER pTokenUser = NULL;
	status = SeQueryInformationToken(SeQuerySubjectContextToken(&(Data->Iopb->Parameters.Create.SecurityContext->AccessState->SubjectSecurityContext)), TokenUser, &pTokenUser);
	if (STATUS_SUCCESS == status && RtlValidSid(pTokenUser->User.Sid))
	{
		// pTokenUser->User.Sid - this is user SID

		// Interesting extension?
		if (ClaimsmanCheckExtension(&nameInfo->Extension)) {

			CLAIMSMAN_MESSAGE msg;

			UNICODE_STRING ss; // buffer == array of WCHAR!
			status = RtlConvertSidToUnicodeString(&ss, pTokenUser->User.Sid, TRUE);
			/*
			if (NT_SUCCESS(status)) {
			PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
			("claimsman!claimsmanPostOperation: SID=%wZ\n", &ss));
			*/
			InitializeMessage(&msg, &ss, nameToUse);
			RtlFreeUnicodeString(&ss);


			// Ready, send the message!
			// But only if there's a client connected
			if (ClaimsmanData.ClientPort != NULL) {
				status = FltSendMessage(ClaimsmanData.Filter,
					&ClaimsmanData.ClientPort,
					&msg,
					sizeof(msg),
					NULL,
					0,
					NULL
					);
				PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
					("claimsman!claimsmanPostOperation: sent message=%d\n", status));
			}
			else {
				PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
					("claimsman!claimsmanPostOperation: no client connected!"));
			}



		}

		/*
		UNICODE_STRING ss;

		status = RtlConvertSidToUnicodeString(&ss, pTokenUser->User.Sid, TRUE);
		if (NT_SUCCESS(status)) {
		PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanPostOperation: SID=%wZ\n", &ss));
		RtlFreeUnicodeString(&ss);
		}
		else {
		PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanPostOperation: problem creating SID string\n"));
		}

		*/
		// Query by using SecLookupAccountSid 
	}

	/*
	// Build message
	CLAIMSMAN_MESSAGE *msg = {0};
	status = RtlConvertSidToUnicodeString(msg->StringSid, pTokenUser->User.Sid, TRUE);
	msg->Name = nameToUse;

	// SEND MESSAGE
	// But only if there's a client connected
	if (ClaimsmanData.ClientPort != NULL) {
	status = FltSendMessage(ClaimsmanData.Filter,
	&ClaimsmanData.ClientPort,
	msg,
	sizeof(msg),
	NULL,
	0,
	NULL
	);
	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
	("claimsman!claimsmanPostOperation: sent message=%d\n", status));
	} else {
	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
	("claimsman!claimsmanPostOperation: no client connected!"));
	}
	*/
	return FLT_POSTOP_FINISHED_PROCESSING;
}


FLT_PREOP_CALLBACK_STATUS
claimsmanPreOperationNoPostOperation(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_Flt_CompletionContext_Outptr_ PVOID *CompletionContext
)
/*++

Routine Description:

This routine is a pre-operation dispatch routine for this miniFilter.

This is non-pageable because it could be called on the paging path

Arguments:

Data - Pointer to the filter callbackData that is passed to us.

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance, its associated volume and
file object.

CompletionContext - The context for the completion routine for this
operation.

Return Value:

The return value is the status of the operation.

--*/
{
	UNREFERENCED_PARAMETER(Data);
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(CompletionContext);

	PT_DBG_PRINT(PTDBG_TRACE_ROUTINES,
		("claimsman!claimsmanPreOperationNoPostOperation: Entered\n"));

	// This template code does not do anything with the callbackData, but
	// rather returns FLT_PREOP_SUCCESS_NO_CALLBACK.
	// This passes the request down to the next miniFilter in the chain.

	return FLT_PREOP_SUCCESS_NO_CALLBACK;
}


BOOLEAN
claimsmanDoRequestOperationStatus(
_In_ PFLT_CALLBACK_DATA Data
)
/*++

Routine Description:

This identifies those operations we want the operation status for.  These
are typically operations that return STATUS_PENDING as a normal completion
status.

Arguments:

Return Value:

TRUE - If we want the operation status
FALSE - If we don't

--*/
{
	PFLT_IO_PARAMETER_BLOCK iopb = Data->Iopb;

	//
	//  return boolean state based on which operations we are interested in
	//

	return (BOOLEAN)

		//
		//  Check for oplock operations
		//

		(((iopb->MajorFunction == IRP_MJ_FILE_SYSTEM_CONTROL) &&
		((iopb->Parameters.FileSystemControl.Common.FsControlCode == FSCTL_REQUEST_FILTER_OPLOCK) ||
		(iopb->Parameters.FileSystemControl.Common.FsControlCode == FSCTL_REQUEST_BATCH_OPLOCK) ||
		(iopb->Parameters.FileSystemControl.Common.FsControlCode == FSCTL_REQUEST_OPLOCK_LEVEL_1) ||
		(iopb->Parameters.FileSystemControl.Common.FsControlCode == FSCTL_REQUEST_OPLOCK_LEVEL_2)))

		||

		//
		//    Check for directy change notification
		//

		((iopb->MajorFunction == IRP_MJ_DIRECTORY_CONTROL) &&
		(iopb->MinorFunction == IRP_MN_NOTIFY_CHANGE_DIRECTORY))
		);
}

NTSTATUS
ClaimsmanConnect(
_In_ PFLT_PORT ClientPort,
_In_ PVOID ServerPortCookie,
_In_reads_bytes_(SizeOfContext) PVOID ConnectionContext,
_In_ ULONG SizeOfContext,
_Flt_ConnectionCookie_Outptr_ PVOID *ConnectionCookie
)
/*++

Routine Description

This is called when user-mode connects to the server
port - to establish a connection

Arguments

ClientPort - This is the pointer to the client port that
will be used to send messages from the filter.
ServerPortCookie - unused
ConnectionContext - unused
SizeofContext   - unused
ConnectionCookie - unused

Return Value

STATUS_SUCCESS - to accept the connection
--*/
{

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ServerPortCookie);
	UNREFERENCED_PARAMETER(ConnectionContext);
	UNREFERENCED_PARAMETER(SizeOfContext);
	UNREFERENCED_PARAMETER(ConnectionCookie);

	ClaimsmanData.ClientPort = ClientPort;
	return STATUS_SUCCESS;
}


VOID
ClaimsmanDisconnect(
_In_opt_ PVOID ConnectionCookie
)
/*++

Routine Description

This is called when the connection is torn-down. We use it to close our handle to the connection

Arguments

ConnectionCookie - unused

Return value

None
--*/
{

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ConnectionCookie);

	//
	//  Close our handle
	//

	FltCloseClientPort(ClaimsmanData.Filter, &ClaimsmanData.ClientPort);
	ClaimsmanData.ClientPort = NULL;
}

NTSTATUS
InitializeMonitoredExtensions(
_In_ PUNICODE_STRING RegistryPath
)
/*++

Routine Descrition:

This routine sets the the extensions for files to be monitored based
on the registry.

Arguments:

RegistryPath - The path key passed to the driver during DriverEntry.

Return Value:

STATUS_SUCCESS if the function completes successfully.  Otherwise a valid
NTSTATUS code is returned.

--*/
{
	NTSTATUS status;
	OBJECT_ATTRIBUTES attributes;
	HANDLE driverRegKey = NULL;
	UNICODE_STRING valueName;
	PKEY_VALUE_PARTIAL_INFORMATION valueBuffer = NULL;
	ULONG valueLength = 0;
	BOOLEAN closeHandle = FALSE;
	PWCHAR ch;
	SIZE_T length;
	ULONG count;
	PUNICODE_STRING ext;

	PAGED_CODE();

	ClaimsmanData.MonitoredExtensions = NULL;
	ClaimsmanData.MonitoredExtensionCount = 0;

	//
	//  Open the driver registry key.
	//

	InitializeObjectAttributes(&attributes,
		RegistryPath,
		OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
		NULL,
		NULL);

	status = ZwOpenKey(&driverRegKey,
		KEY_READ,
		&attributes);

	if (!NT_SUCCESS(status)) {

		goto InitializeMonitoredExtensionsCleanup;
	}

	closeHandle = TRUE;

	//
	//   Query the length of the reg value
	//

	RtlInitUnicodeString(&valueName, L"Extensions");

	status = ZwQueryValueKey(driverRegKey,
		&valueName,
		KeyValuePartialInformation,
		NULL,
		0,
		&valueLength);

	if (status != STATUS_BUFFER_TOO_SMALL && status != STATUS_BUFFER_OVERFLOW) {

		status = STATUS_INVALID_PARAMETER;
		goto InitializeMonitoredExtensionsCleanup;
	}

	//
	//  Extract the path.
	//

	valueBuffer = ExAllocatePoolWithTag(NonPagedPool,
		valueLength,
		CLAIMSMAN_REG_TAG);

	if (valueBuffer == NULL) {

		status = STATUS_INSUFFICIENT_RESOURCES;
		goto InitializeMonitoredExtensionsCleanup;
	}

	status = ZwQueryValueKey(driverRegKey,
		&valueName,
		KeyValuePartialInformation,
		valueBuffer,
		valueLength,
		&valueLength);

	if (!NT_SUCCESS(status)) {

		goto InitializeMonitoredExtensionsCleanup;
	}

	ch = (PWCHAR)(valueBuffer->Data);

	count = 0;

	//
	//  Count how many strings are in the multi string
	//

	while (*ch != '\0') {

		ch = ch + wcslen(ch) + 1;
		count++;
	}

	ClaimsmanData.MonitoredExtensions = ExAllocatePoolWithTag(PagedPool,
		count * sizeof(UNICODE_STRING),
		CLAIMSMAN_STRING_TAG);

	if (ClaimsmanData.MonitoredExtensions == NULL) {
		goto InitializeMonitoredExtensionsCleanup;
	}

	ch = (PWCHAR)((PKEY_VALUE_PARTIAL_INFORMATION)valueBuffer->Data);
	ext = ClaimsmanData.MonitoredExtensions;

	while (ClaimsmanData.MonitoredExtensionCount < count) {

		length = wcslen(ch) * sizeof(WCHAR);

		ext->MaximumLength = (USHORT)length;

		status = ClaimsmanAllocateUnicodeString(ext);

		if (!NT_SUCCESS(status)) {
			goto InitializeMonitoredExtensionsCleanup;
		}

		ext->Length = (USHORT)length;

		RtlCopyMemory(ext->Buffer, ch, length);

		ch = ch + length / sizeof(WCHAR) + 1;

		ClaimsmanData.MonitoredExtensionCount++;

		ext++;

	}

InitializeMonitoredExtensionsCleanup:

	//
	//  Note that this function leaks the global buffers.
	//  On failure DriverEntry will clean up the globals
	//  so we don't have to do that here.
	//

	if (valueBuffer != NULL) {

		ExFreePoolWithTag(valueBuffer, CLAIMSMAN_REG_TAG);
		valueBuffer = NULL;
	}

	if (closeHandle) {

		ZwClose(driverRegKey);
	}

	if (!NT_SUCCESS(status)) {

		ClaimsmanFreeExtensions();
	}

	return status;
}


VOID
ClaimsmanFreeExtensions(
)
/*++

Routine Descrition:

This routine cleans up the global buffers on both
teardown and initialization failure.

Arguments:

Return Value:

None.

--*/
{
	PAGED_CODE();

	//
	// Free the strings in the scanned extension array
	//

	while (ClaimsmanData.MonitoredExtensionCount > 0) {

		ClaimsmanData.MonitoredExtensionCount--;

		if (ClaimsmanData.MonitoredExtensions != &MonitoredExtensionDefault) {

			ClaimsmanFreeUnicodeString(ClaimsmanData.MonitoredExtensions + ClaimsmanData.MonitoredExtensionCount);
		}
	}

	if (ClaimsmanData.MonitoredExtensions != &MonitoredExtensionDefault && ClaimsmanData.MonitoredExtensions != NULL) {

		ExFreePoolWithTag(ClaimsmanData.MonitoredExtensions, CLAIMSMAN_STRING_TAG);
	}

	ClaimsmanData.MonitoredExtensions = NULL;

}


NTSTATUS
ClaimsmanAllocateUnicodeString(
_Inout_ PUNICODE_STRING String
)
/*++

Routine Description:

This routine allocates a unicode string

Arguments:

String - supplies the size of the string to be allocated in the MaximumLength field
return the unicode string

Return Value:

STATUS_SUCCESS                  - success
STATUS_INSUFFICIENT_RESOURCES   - failure

--*/
{

	PAGED_CODE();

	String->Buffer = ExAllocatePoolWithTag(NonPagedPool,
		String->MaximumLength,
		CLAIMSMAN_STRING_TAG);

	if (String->Buffer == NULL) {

		return STATUS_INSUFFICIENT_RESOURCES;
	}

	String->Length = 0;

	return STATUS_SUCCESS;
}


VOID
ClaimsmanFreeUnicodeString(
_Inout_ PUNICODE_STRING String
)
/*++

Routine Description:

This routine frees a unicode string

Arguments:

String - supplies the string to be freed

Return Value:

None

--*/
{
	PAGED_CODE();

	if (String->Buffer) {

		ExFreePoolWithTag(String->Buffer,
			CLAIMSMAN_STRING_TAG);
		String->Buffer = NULL;
	}

	String->Length = String->MaximumLength = 0;
	String->Buffer = NULL;
}


BOOLEAN
ClaimsmanCheckExtension(
_In_ PUNICODE_STRING Extension
)
/*++

Routine Description:

Checks if this file name extension is something we are interested in

Arguments

Extension - Pointer to the file name extension

Return Value

TRUE - Yes we are interested
FALSE - No
--*/
{
	ULONG count;

	if (Extension == NULL || Extension->Length == 0) {

		return FALSE;
	}

	//
	//  Check if it matches any one of our static extension list
	//

	for (count = 0; count < ClaimsmanData.MonitoredExtensionCount; count++) {

		if (RtlCompareUnicodeString(Extension, ClaimsmanData.MonitoredExtensions + count, TRUE) == 0) {

			//
			//  A match. We are interested in this file
			//

			return TRUE;
		}
	}

	return FALSE;
}