
#ifndef __CLAIMSMAN_H__
#define __CLAIMSMAN_H__


#define CLAIMSMAN_MESSAGE_FILENAME_SIZE   512
#define CLAIMSMAN_MESSAGE_SID_SIZE        256

typedef struct _CLAIMSMAN_MESSAGE {
	// File name
	WCHAR FileName[CLAIMSMAN_MESSAGE_FILENAME_SIZE];

	// SID
	WCHAR Sid[CLAIMSMAN_MESSAGE_SID_SIZE];

} CLAIMSMAN_MESSAGE;

typedef struct _CLAIMSMAN_DATA {

	//
	//  The object that identifies this driver.
	//

	PDRIVER_OBJECT DriverObject;

	//
	//  The filter that results from a call to
	//  FltRegisterFilter.
	//

	PFLT_FILTER Filter;

	//
	//  Server port: user mode connects to this port
	//

	PFLT_PORT ServerPort;

	//
	//  Client connection port: only one connection is allowed at a time.,
	//

	PFLT_PORT ClientPort;

	//
	//  File name extensions files we are interested in monitoring
	//

	PUNICODE_STRING MonitoredExtensions;
	ULONG MonitoredExtensionCount;

} CLAIMSMAN_DATA;

const PWSTR ClaimsmanPortName = L"\\ClaimsmanPort";

#define CLAIMSMAN_STRING_TAG    'Sncs'
#define CLAIMSMAN_REG_TAG    'Sb'

#endif //  __CLAIMSMAN_H__
